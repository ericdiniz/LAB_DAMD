# TODO

- [x] Exercício 1 – Data de vencimento: modelo, migração de banco e interface (formulário, ordenação, alertas).
- [x] Exercício 2 – Categorias: modelo, coluna no banco, formulário, filtro e cores.
- [x] Atualizar documentação do entregável destacando as novas funcionalidades.
