package com.example.task_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
